﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Forum_GeeksForLess.Migrations.ContentDb
{
    public partial class changeTopicType : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
