﻿using Forum_GeeksForLess.Models;
using Forum_GeeksForLess.Models.Repositories;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Forum_GeeksForLess.Controllers
{
    public class UserController : Controller
    {
        private IContentRepository _contentRepo { get; set; }
        private IWebHostEnvironment _env { get; set; }

        public UserController(IContentRepository repo, IWebHostEnvironment webHostEnvironment)
        {
            _env = webHostEnvironment;
            _contentRepo = repo;
        }
        
        public IActionResult WhatToCreate()
        {
            if (User.Identity.IsAuthenticated)
            {
                return View();
            }
            return View("Error");
        }

        public IActionResult CreateArticle(int? id = null)
        {
            if (User.Identity.IsAuthenticated)
            {
                if (id != null)
                {
                    Article art = _contentRepo.GetArticle(id);
                    if (User.Identity.Name == art.Author)
                    {
                        return View(art);
                    }

                    return View("Error", "seems like it's not your article or topic, please try edit your works");
                }

                return View();
            }
            return View("Error");
        }

        [HttpPost]
        public IActionResult CreateArticle(Article article)
        {
            if (ModelState.IsValid)
            {
                var topics = _contentRepo.Topics.FirstOrDefault(m => m.Title == article.TopicTitle);
                if (topics != null)
                {
                    article.Author = User.Identity.Name;
                    _contentRepo.AddArticle(article);
                    return RedirectToAction("Index", "Home");
                }                
            }
            return View(article);
        }

        public IActionResult EditArticle(int id)
        {
            if (User.Identity.IsAuthenticated && _contentRepo.GetArticle(id).Author == User.Identity.Name)
            {
                return View(_contentRepo.GetArticle(id));
            }
            return View("Error", "seems, like it's not your article or topic, please try edit your works");
        }

        [HttpPost]
        public IActionResult EditArticle(Article article)
        {
            if (ModelState.IsValid)
            {
                var topics = _contentRepo.Topics.FirstOrDefault(m => m.Title == article.TopicTitle);
                if (topics != null)
                {
                    if (User.Identity.IsAuthenticated)
                    {
                        _contentRepo.EditArticle(article);
                        return RedirectToAction("Index", "Home");
                    }
                    return View("Error");
                }
            }
            return View(article);
        }

        public IActionResult DeleteArticle(int id)
        {
            if (User.Identity.IsAuthenticated)
            {
                _contentRepo.DeleteArticle(id);
                return RedirectToAction("Index", "Home");
            }
            return View("Error");
        } 

        public IActionResult CreateTopic()
        {
            if (User.Identity.IsAuthenticated)
            {
                return View();
            }
            return View("Error");
        }

        [HttpPost]
        public IActionResult CreateTopic(IFormFile upload, Topic topic)
        {
            try
            {
                if (upload != null)
                {
                    FileInfo file = new FileInfo(upload.FileName);
                    var fileName = "Image_" + DateTime.Now.TimeOfDay.Milliseconds + file.Extension;
                    var filePath = Path.Combine("", @"~/images/" + fileName);
                    var uploadPath = Path.Combine("", _env.WebRootPath + @"\images\" + fileName);
                    using (var stream = new FileStream(uploadPath, FileMode.Create))
                    {
                        upload.CopyTo(stream);
                    }
                    Image img = new Image();
                    img.Path = filePath;
                    img.Date = DateTime.Now;

                    topic.img = img;
                }
            }
            catch (Exception e)
            {
                return View("Error", e);
            }

            _contentRepo.AddTopic(topic);
            return View(nameof(WhatToCreate));
        }
    }
}
