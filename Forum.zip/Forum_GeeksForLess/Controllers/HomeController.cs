﻿using Forum_GeeksForLess.Models;
using Forum_GeeksForLess.Models.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Forum_GeeksForLess.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IContentRepository _contentRepository { get; set; }

        public HomeController(ILogger<HomeController> logger, IContentRepository contentRepo)
        {
            _contentRepository = contentRepo;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View(_contentRepository.Topics);
        }

        public IActionResult Articles(string topicTitle = null)
        { 
            if(topicTitle == null)
            {
                return View(_contentRepository.Articles.Where(m => m.Author == User.Identity.Name));
            }

            return View(_contentRepository.Articles.Where(m => m.TopicTitle == topicTitle));
        }
        
        public IActionResult Article(int id)
        {            
            return View(_contentRepository.GetArticle(id));
        }

    }
}
