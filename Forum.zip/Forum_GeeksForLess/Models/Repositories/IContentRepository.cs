﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Forum_GeeksForLess.Models.Repositories
{
    public interface IContentRepository
    {
        public void AddTopic(Topic topic);
        public void AddArticle(Article article);
        public void EditArticle(Article article);
        public void DeleteArticle(int id);
        public Article GetArticle(int? id);
        public IEnumerable<Topic> Topics { get; }
        public IEnumerable<Article> Articles { get; }
    }
}
