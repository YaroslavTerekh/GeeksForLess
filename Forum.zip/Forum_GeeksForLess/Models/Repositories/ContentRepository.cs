﻿using Forum_GeeksForLess.Models.DbContexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Forum_GeeksForLess.Models.Repositories
{
    public class ContentRepository : IContentRepository
    {
        private ContentDbContext _context { get; set; }

        public ContentRepository(ContentDbContext ctx)
        {
            _context = ctx;
        }

        public void AddTopic(Topic topic)
        {
            _context.Add(topic);
            _context.SaveChanges();
        }

        public void AddArticle(Article article)
        {
            _context.Articles.Add(article);
            _context.SaveChanges();
        }

        public Article GetArticle(int? id)
        {
            return _context.Articles.FirstOrDefault(m => m.Id == id);
        }

        public void DeleteArticle(int id)
        {
            _context.Articles.Remove(GetArticle(id));
            _context.SaveChanges();
        }

        public void EditArticle(Article article)
        {
            Article oldArticle = GetArticle(article.Id);

            oldArticle.Title = article.Title;
            oldArticle.TopicTitle = article.TopicTitle;
            oldArticle.Description = article.Description;

            _context.SaveChanges();
        }

        public IEnumerable<Topic> Topics => _context.Topics.Include(m => m.img);
        public IEnumerable<Article> Articles => _context.Articles.ToArray();
    }
}
