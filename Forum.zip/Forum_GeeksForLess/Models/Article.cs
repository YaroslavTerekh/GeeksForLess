﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Forum_GeeksForLess.Models
{
    public class Article
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Title")]
        [MaxLength(30, ErrorMessage = "Length mustn't be greater than 30 chars")]
        public string Title { get; set; }

        [Required]
        [Display(Name = "Description of your article")]
        [MinLength(50, ErrorMessage = "Length of description must be at least 50 chars")]
        public string Description { get; set; }

        [Required]
        [Display(Name = "Title of topic")]
        public string TopicTitle { get; set; }
        public string Author { get; set; }
    }
}
