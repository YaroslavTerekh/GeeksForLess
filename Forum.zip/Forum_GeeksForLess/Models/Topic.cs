﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Forum_GeeksForLess.Models
{
    public class Topic
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(15)]
        [Display(Name = "Title of topic")]
        public string Title { get; set; }
        [Required]
        [MaxLength(30)]
        [Display(Name = "Short description of topic")]
        public string Description { get; set; }
        [Required]
        public Image img { get; set; }
    }
}
